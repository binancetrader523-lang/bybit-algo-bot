"""Bybit 1H Liquidity Sweep + MSS + FVG(50%) demo bot starter.

Safety defaults: demo environment only, order execution disabled until explicitly armed.
"""
import os, time, threading, logging
from datetime import datetime, timezone
from typing import Optional

import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from pybit.unified_trading import HTTP

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("algo-bot")

API_KEY = os.getenv("BYBIT_DEMO_API_KEY", "")
API_SECRET = os.getenv("BYBIT_DEMO_API_SECRET", "")
DEMO_MODE = os.getenv("DEMO_MODE", "true").lower() == "true"
SCAN_INTERVAL = int(os.getenv("SCAN_INTERVAL_SECONDS", "300"))
MAX_SYMBOLS_PER_CYCLE = int(os.getenv("MAX_SYMBOLS_PER_CYCLE", "100"))

app = FastAPI(title="Bybit Algo Bot — Demo")
app.mount("/static", StaticFiles(directory="static"), name="static")

state = {
    "running": False, "armed": False, "demo_mode": DEMO_MODE,
    "last_scan": None, "symbols_scanned": 0, "signals": [], "trades": [],
    "logs": ["Ready. Demo mode is required; order execution is OFF by default."],
    "risk_usd": 1.0, "max_open_trades": 3, "symbols": [], "scan_index": 0,
}
lock = threading.Lock()
worker_thread: Optional[threading.Thread] = None


def add_log(msg: str):
    with lock:
        state["logs"].insert(0, f"{datetime.now().strftime('%H:%M:%S')}  {msg}")
        state["logs"] = state["logs"][:100]


def client():
    if not DEMO_MODE:
        raise RuntimeError("This starter only permits Bybit demo mode. Set DEMO_MODE=true.")
    if not API_KEY or not API_SECRET:
        raise RuntimeError("Add BYBIT_DEMO_API_KEY and BYBIT_DEMO_API_SECRET to the server environment first.")
    return HTTP(testnet=False, demo=True, api_key=API_KEY, api_secret=API_SECRET)


def get_symbols(session):
    result = []
    cursor = None
    while True:
        kwargs = {"category": "linear", "limit": 1000}
        if cursor:
            kwargs["cursor"] = cursor
        data = session.get_instruments_info(**kwargs)
        for item in data.get("result", {}).get("list", []):
            if item.get("status") == "Trading" and item.get("quoteCoin") == "USDT":
                result.append(item["symbol"])
        cursor = data.get("result", {}).get("nextPageCursor")
        if not cursor:
            break
    return sorted(set(result))


def candles(session, symbol, limit=100):
    res = session.get_kline(category="linear", symbol=symbol, interval="60", limit=limit)
    rows = res.get("result", {}).get("list", [])
    if len(rows) < 30:
        return None
    # Bybit returns newest first: startTime, open, high, low, close, volume, turnover
    df = pd.DataFrame(rows, columns=["time", "open", "high", "low", "close", "volume", "turnover"])
    df = df.iloc[::-1].reset_index(drop=True)
    for col in ["open", "high", "low", "close", "volume"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df["time"] = pd.to_numeric(df["time"], errors="coerce")
    # Exclude the currently forming 1H candle.
    return df.iloc[:-1].dropna().reset_index(drop=True)


def pivot_high(df, idx, left=2, right=2):
    if idx-left < 0 or idx+right >= len(df): return False
    v = df.loc[idx, "high"]
    return v >= df.loc[idx-left:idx+right, "high"].max() and (df.loc[idx-left:idx+right, "high"] == v).sum() == 1


def pivot_low(df, idx, left=2, right=2):
    if idx-left < 0 or idx+right >= len(df): return False
    v = df.loc[idx, "low"]
    return v <= df.loc[idx-left:idx+right, "low"].min() and (df.loc[idx-left:idx+right, "low"] == v).sum() == 1


def detect_signal(df, symbol):
    """Heuristic, closed-candle-only interpretation of sweep -> MSS -> FVG midpoint.

    This is a rule-based approximation, not a universal definition of SMC/ICT.
    """
    if df is None or len(df) < 35: return None
    end = len(df) - 1
    start = max(10, end - 12)
    # Find recent confirmed swing levels before the potential sweep.
    for sweep_i in range(end - 5, start - 1, -1):
        prior = df.iloc[max(0, sweep_i-25):sweep_i]
        if len(prior) < 10: continue
        highs = [i for i in range(max(2, sweep_i-25), sweep_i-2) if pivot_high(df, i)]
        lows = [i for i in range(max(2, sweep_i-25), sweep_i-2) if pivot_low(df, i)]
        if not highs or not lows: continue
        swing_hi_i, swing_lo_i = highs[-1], lows[-1]
        swing_hi, swing_lo = float(df.loc[swing_hi_i, "high"]), float(df.loc[swing_lo_i, "low"])
        sw = df.loc[sweep_i]
        # Bullish sweep: pierce prior swing low and close back above it.
        if float(sw.low) < swing_lo and float(sw.close) > swing_lo:
            for mss_i in range(sweep_i+1, min(end+1, sweep_i+7)):
                if float(df.loc[mss_i, "close"]) <= swing_hi: continue
                # bullish FVG: low of candle 3 is above high of candle 1
                for fvg_i in range(mss_i, min(end+1, mss_i+5)):
                    if fvg_i < 2: continue
                    bottom = float(df.loc[fvg_i-2, "high"])
                    top = float(df.loc[fvg_i, "low"])
                    if top > bottom:
                        entry = (top + bottom) / 2
                        stop = float(sw.low)
                        if entry <= stop: continue
                        target = entry + 2*(entry-stop)
                        return {"symbol": symbol, "side": "Buy", "direction": "LONG", "entry": entry,
                                "sl": stop, "tp": target, "rr": "1:2", "fvg_bottom": bottom,
                                "fvg_top": top, "sweep_time": int(sw.time), "signal_time": int(df.loc[fvg_i, "time"]),
                                "reason": "Low sweep + bullish MSS + bullish FVG 50%"}
        # Bearish sweep: pierce prior swing high and close back below it.
        if float(sw.high) > swing_hi and float(sw.close) < swing_hi:
            for mss_i in range(sweep_i+1, min(end+1, sweep_i+7)):
                if float(df.loc[mss_i, "close"]) >= swing_lo: continue
                for fvg_i in range(mss_i, min(end+1, mss_i+5)):
                    if fvg_i < 2: continue
                    top = float(df.loc[fvg_i-2, "low"])
                    bottom = float(df.loc[fvg_i, "high"])
                    if top > bottom:
                        entry = (top + bottom) / 2
                        stop = float(sw.high)
                        if entry >= stop: continue
                        target = entry - 2*(stop-entry)
                        return {"symbol": symbol, "side": "Sell", "direction": "SHORT", "entry": entry,
                                "sl": stop, "tp": target, "rr": "1:2", "fvg_bottom": bottom,
                                "fvg_top": top, "sweep_time": int(sw.time), "signal_time": int(df.loc[fvg_i, "time"]),
                                "reason": "High sweep + bearish MSS + bearish FVG 50%"}
    return None


def quantity_for_risk(session, symbol, entry, stop, risk):
    distance = abs(entry-stop)
    if distance <= 0: return 0
    raw_qty = risk / distance
    info = session.get_instruments_info(category="linear", symbol=symbol)["result"]["list"][0]
    lot = info.get("lotSizeFilter", {})
    step = float(lot.get("qtyStep", "1"))
    min_qty = float(lot.get("minOrderQty", "0"))
    max_qty = float(lot.get("maxOrderQty", raw_qty))
    qty = min(max_qty, (raw_qty // step) * step)
    if qty < min_qty: return 0
    return float(f"{qty:.8f}")


def execute_demo_order(session, sig):
    if not state["armed"]:
        return "Signal only: demo execution not armed."
    if not DEMO_MODE:
        return "Blocked: demo mode required."
    with lock:
        open_count = sum(1 for t in state["trades"] if t.get("status") == "SUBMITTED")
        risk = float(state["risk_usd"])
        max_open = int(state["max_open_trades"])
    if open_count >= max_open:
        return "Skipped: max open demo trades reached."
    qty = quantity_for_risk(session, sig["symbol"], sig["entry"], sig["sl"], risk)
    if qty <= 0:
        return "Skipped: calculated quantity is below exchange minimum."
    # Entry order has attached SL/TP. It is a limit order at the FVG midpoint.
    result = session.place_order(category="linear", symbol=sig["symbol"], side=sig["side"],
        orderType="Limit", qty=str(qty), price=str(sig["entry"]), timeInForce="GTC",
        positionIdx=0, stopLoss=str(sig["sl"]), takeProfit=str(sig["tp"]),
        tpslMode="Full", slOrderType="Market", tpOrderType="Market")
    sig["qty"] = qty
    sig["order_id"] = result.get("result", {}).get("orderId")
    sig["status"] = "SUBMITTED"
    sig["created_at"] = datetime.now(timezone.utc).isoformat()
    with lock:
        state["trades"].insert(0, sig.copy())
        state["trades"] = state["trades"][:200]
    return f"Demo limit order submitted: {sig['symbol']} {sig['direction']} qty={qty}"


def scan_once():
    session = client()
    with lock:
        symbols = state["symbols"][:]
    if not symbols:
        symbols = get_symbols(session)
        with lock: state["symbols"] = symbols
        add_log(f"Loaded {len(symbols)} eligible USDT perpetual symbols.")
    if not symbols: return
    # Rotate through the universe so all pairs are scanned over successive cycles.
    with lock:
        start = state["scan_index"]
        batch = symbols[start:start+MAX_SYMBOLS_PER_CYCLE]
        if len(batch) < MAX_SYMBOLS_PER_CYCLE:
            batch += symbols[:MAX_SYMBOLS_PER_CYCLE-len(batch)]
        state["scan_index"] = (start + MAX_SYMBOLS_PER_CYCLE) % len(symbols)
    new_count = 0
    for symbol in batch:
        try:
            df = candles(session, symbol)
            sig = detect_signal(df, symbol)
            if sig:
                with lock:
                    exists = any(x.get("symbol") == symbol and x.get("signal_time") == sig["signal_time"] and x.get("direction") == sig["direction"] for x in state["signals"])
                if not exists:
                    sig["status"] = "SIGNAL"
                    sig["created_at"] = datetime.now(timezone.utc).isoformat()
                    with lock:
                        state["signals"].insert(0, sig.copy())
                        state["signals"] = state["signals"][:200]
                    new_count += 1
                    add_log(f"Signal: {symbol} {sig['direction']} — {sig['reason']}")
                    try: add_log(execute_demo_order(session, sig.copy()))
                    except Exception as e: add_log(f"Order not placed for {symbol}: {e}")
            time.sleep(0.08)
        except Exception as e:
            log.warning("Scan error for %s: %s", symbol, e)
    with lock:
        state["symbols_scanned"] += len(batch)
        state["last_scan"] = datetime.now(timezone.utc).isoformat()
    add_log(f"Scan batch complete: {len(batch)} symbols, {new_count} new signal(s).")


def worker():
    add_log("Scanner started. Timeframe: 1H; strategy: sweep → MSS → FVG 50%; RR 1:2.")
    while True:
        with lock:
            if not state["running"]: break
        try: scan_once()
        except Exception as e: add_log(f"Scan failed: {e}")
        for _ in range(max(1, SCAN_INTERVAL)):
            with lock:
                if not state["running"]: break
            time.sleep(1)
    add_log("Scanner stopped.")


class Settings(BaseModel):
    risk_usd: float = Field(default=1.0, gt=0, le=10)
    max_open_trades: int = Field(default=3, ge=1, le=5)

@app.get("/", response_class=HTMLResponse)
def home():
    with open("static/index.html", "r", encoding="utf-8") as f: return f.read()

@app.get("/api/status")
def status():
    with lock:
        return {k: v for k, v in state.items() if k != "symbols"}

@app.post("/api/settings")
def settings(body: Settings):
    with lock:
        state["risk_usd"] = body.risk_usd
        state["max_open_trades"] = body.max_open_trades
    return {"ok": True, "risk_usd": body.risk_usd, "max_open_trades": body.max_open_trades}

@app.post("/api/start")
def start():
    global worker_thread
    if not DEMO_MODE: raise HTTPException(403, "This build is demo-only. Set DEMO_MODE=true.")
    try: client()
    except Exception as e: raise HTTPException(400, str(e))
    with lock:
        if state["running"]: return {"ok": True, "message": "Already running."}
        state["running"] = True
    worker_thread = threading.Thread(target=worker, daemon=True)
    worker_thread.start()
    return {"ok": True, "message": "Started."}

@app.post("/api/stop")
def stop():
    with lock: state["running"] = False
    return {"ok": True, "message": "Stopping scanner."}

@app.post("/api/arm-demo-orders")
def arm_demo_orders():
    if not DEMO_MODE: raise HTTPException(403, "Demo mode only.")
    try: client()
    except Exception as e: raise HTTPException(400, str(e))
    with lock: state["armed"] = True
    add_log("Demo order execution ARMED by user. Verify demo API keys and settings.")
    return {"ok": True, "message": "Demo order execution armed."}

@app.post("/api/disarm-demo-orders")
def disarm_demo_orders():
    with lock: state["armed"] = False
    add_log("Demo order execution disarmed. Scanner can continue in signal-only mode.")
    return {"ok": True, "message": "Demo orders disarmed."}

@app.post("/api/scan-once")
def scan_once_endpoint():
    try: scan_once()
    except Exception as e: raise HTTPException(400, str(e))
    return {"ok": True, "message": "Scan batch completed."}
