# Bybit Algo Bot — Demo Starter

A mobile-friendly web dashboard and Python backend for a **demo-only** Bybit USDT perpetual scanner. Strategy: 1H closed candles, approximate liquidity sweep → MSS → FVG midpoint, fixed 1:2 target. It scans symbols in batches and rotates through the eligible USDT perpetual universe.

## Important limitations
- This is a starter implementation, not a validated profitable strategy.
- SMC/ICT terms are not uniquely standardized; the code uses explicit heuristic definitions that need backtesting and review.
- Default behavior is **signal-only**. You must press **Arm Demo Orders** to allow demo orders.
- This build blocks real trading. Do not add real-account API keys.
- The API order call/attached SL/TP behavior should be verified against the current Bybit Demo environment before use.
- Keep demo API keys on the backend environment only. Never paste API secrets into chat or browser code.
- Bybit API access and demo availability may vary by account/region.

## Setup

1. Create **Demo Trading** API keys in Bybit. Give only the permissions required for reading market data and placing demo orders; do not use real-account keys.
2. Copy `.env.example` to `.env` and fill in the demo API key/secret. Keep `.env` private.
3. Install Python 3.11+ and dependencies:

   ```bash
   python -m venv .venv
   source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
   pip install -r requirements.txt
   ```

4. Export the environment variables from `.env` (or configure them in your host's secret/environment settings). Example Linux/macOS:

   ```bash
   set -a; source .env; set +a
   uvicorn app:app --host 0.0.0.0 --port 8000
   ```

5. Open `http://127.0.0.1:8000` locally, or the private HTTPS URL from a secure host. On Android, use the host URL in Chrome.
6. Start with **Start Scanner** and keep demo orders disarmed. Review signals first. Only arm demo orders after verifying the rules and exchange behavior.

## Mobile-only note
The app can be controlled from Android, but the Python backend must run somewhere continuously (a computer or server). Free hosting is not guaranteed to keep a process alive, and API keys must be stored securely. This zip is source code; it is not an already-installed Android APK or an already-hosted bot.

## Strategy definition in this starter
- 1H candles only; the forming candle is excluded.
- Recent confirmed swing high/low candidates are identified with a 2-left/2-right pivot rule.
- Sweep: price crosses a prior swing level and the same candle closes back on the other side.
- MSS: a subsequent candle closes through the opposite recent swing level.
- FVG: three-candle imbalance; entry is its midpoint.
- Stop: sweep candle extreme; target: 2R.

These definitions are a first-pass approximation. Run historical backtests and inspect chart examples before considering any live deployment.
